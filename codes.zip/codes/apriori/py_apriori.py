from itertools import combinations as cmb

for i in cmb([1,2,3,4],3):
    print(i)